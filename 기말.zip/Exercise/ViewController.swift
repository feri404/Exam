//
//  ViewController.swift
//  Exercise
//
//  Created by 강민석 on 2022/06/17.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func btnMoveExersize(_ sender: UIButton) {
        tabBarController?.selectedIndex = 1 // 운동 탭으로 이동
    }
    @IBAction func btnMoveVideo(_ sender: UIButton) {
        tabBarController?.selectedIndex = 2 // 영상 탭으로 이동
    }
}

